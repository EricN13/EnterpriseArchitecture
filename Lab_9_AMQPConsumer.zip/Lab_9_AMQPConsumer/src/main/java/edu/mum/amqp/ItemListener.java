package edu.mum.amqp;

import edu.mum.domain.Item;

public class ItemListener {

	public void listen(Item item) {

		System.out.println("DIRECT Consumer for Item :" + item.getName());
	}

}
