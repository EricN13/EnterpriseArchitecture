package edu.mum.amqp;

import org.springframework.amqp.rabbit.core.RabbitTemplate;

import edu.mum.domain.Item;

public class ItemServiceImpl implements ItemService {

	public void publish(RabbitTemplate rabbitTemplate) {

		Item item = new Item("Kazoo", "Kazoo", 1.0f, 1);
		// Order 2 of them
		rabbitTemplate.convertAndSend(item);

		item = new Item("Hammer", "Hammer", 2.0f, 1);

		rabbitTemplate.convertAndSend(item);

	}

}
