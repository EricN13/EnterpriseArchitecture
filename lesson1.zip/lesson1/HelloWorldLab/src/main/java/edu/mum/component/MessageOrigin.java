package edu.mum.component;

public interface MessageOrigin {
   public String getMessage();
}
