package edu.mum.dream.dao;

import edu.mum.dream.domain.Address;

public interface AddressDao extends GenericDao<Address>{

	
}
