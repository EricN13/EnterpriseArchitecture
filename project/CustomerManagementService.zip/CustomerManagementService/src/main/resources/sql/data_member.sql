NSERT INTO `address` (`city`, `state`, `street`, `zip_code`) 
 VALUES ('Fairfield', 'Iowa', '1000 N 4th St', '52557')


 INSERT INTO `customer` (`email`, `first_name`, `last_name`, `phone_number`,`address_id`) 
VALUES ('mahisharew62@gmail.com', 'Mahlet', 'Borena', '1234567891','1')
 
