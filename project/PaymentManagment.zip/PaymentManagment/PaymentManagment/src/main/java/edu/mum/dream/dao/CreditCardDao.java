package edu.mum.dream.dao;

import edu.mum.dream.domain.CreditCard;

public interface CreditCardDao extends GenericDao<CreditCard>{

}
