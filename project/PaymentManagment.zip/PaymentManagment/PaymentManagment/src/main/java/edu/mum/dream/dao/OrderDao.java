package edu.mum.dream.dao;

import edu.mum.dream.domain.Order;

public interface OrderDao extends GenericDao<Order> {

}
