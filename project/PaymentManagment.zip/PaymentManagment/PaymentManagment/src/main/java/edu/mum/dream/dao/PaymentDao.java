package edu.mum.dream.dao;
 
import edu.mum.dream.domain.Payment;

public interface PaymentDao extends GenericDao<Payment>{

	
}
